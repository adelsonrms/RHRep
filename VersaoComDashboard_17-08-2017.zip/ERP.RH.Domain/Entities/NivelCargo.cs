﻿namespace RH.Domain.Entities
{
    public class NivelCargo
    {
        public virtual int Id { get; set; }
        public virtual string Nivel { get; set; }
    }
}

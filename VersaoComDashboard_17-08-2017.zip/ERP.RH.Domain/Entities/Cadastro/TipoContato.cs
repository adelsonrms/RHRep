﻿namespace RH.Domain.Entities
{
    public class TipoContato
    {
        public int TipoContatoID { get; set; }
        public string Nome { get; set; }
    }
}
﻿namespace RH.Domain.Entities
{
    public class Departamento
    {
        public virtual int Id { get; set; }

        public virtual string NomeDepartamento { get; set; }
    }
}
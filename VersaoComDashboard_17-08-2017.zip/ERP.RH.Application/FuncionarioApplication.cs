﻿using RH.Domain.Entities;
using RH.Domain.Repositories;
using RH.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ERP.RH.Application
{
    public class FuncionarioApplication: EntityApplication<Funcionario>
    {

        public IEnumerable<Funcionario> ObtemListaDeFuncionarios()
        {
            return Rep.ObterTodos();
        }

        public void SalvaFuncionario(Funcionario model)
        {
            try
            {
                Rep.Alterar(model);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            ;
        }

        public Funcionario ObtemFuncionario(Funcionario funcionario)
        {
            try
            {
                //Busca informações relacionadas do contrato de trabalho
                funcionario.Contrato = new ContratoApplication().RecuperaContratoPorFuncionario(funcionario);

                //Obtem informações sobre os documentos
                funcionario.Documento = new EntityApplication<Documento>().ObterTodos().SingleOrDefault(f => f.IdFuncionario == funcionario.Id);

                //Calcula a idade do funcionario baseado na sua data de nascimento
                funcionario.Idade = CalculaIdade(funcionario);
            }
            catch (Exception e)
            {
                funcionario = null;
                Console.WriteLine(e);
            }
            return funcionario;
        }
        /// <summary>
        /// Recupera um funcionario 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Funcionario ObtemFuncionario(int id)
        {
            Funcionario funcionario = null;
            try
            {
                //Busca o funcionario na base
                funcionario = Rep.ObterPorId(id);

                //Busca informações relacionadas do contrato de trabalho
                funcionario.Contrato =  new ContratoApplication().RecuperaContratoPorFuncionario(funcionario);
                funcionario.Documento = new EntityApplication<Documento>().ObterTodos().SingleOrDefault(f => f.IdFuncionario == funcionario.Id);

                //Calcula a idade do funcionario baseado na sua data de nascimento
                funcionario.Idade = CalculaIdade(funcionario);
            }
            catch (Exception e)
            {
                funcionario = null;
                Console.WriteLine(e);
            }
            return funcionario;
        }

        public string CalculaIdade(Funcionario funcionario)
        {
            string idade="";

            if (funcionario.DataNascimento != null)
            {
                idade = new DateService().TempoDecorrido(DateTime.Parse(funcionario.DataNascimento), DateTime.Today, "y");
            }
            return idade;
        }

        public Funcionario ObtemFuncionario(string email)
        {
            Funcionario funcionario = null;
            try
            {
                //Busca o funcionario na base
                funcionario = Rep.ObterTodos().Where(f => f.EmailProfissional == email).SingleOrDefault();

                //Busca informações relacionadas do contrato de trabalho
                funcionario.Contrato = new ContratoApplication().RecuperaContratoPorFuncionario(funcionario);
                funcionario.Documento = new EntityApplication<Documento>().ObterTodos().SingleOrDefault(f => f.IdFuncionario == funcionario.Id);

                //Calcula a idade do funcionario baseado na sua data de nascimento
                funcionario.Idade = CalculaIdade(funcionario);
            }
            catch (Exception e)
            {
                funcionario = null;
                Console.WriteLine(e);
            }
            return funcionario;
        }


    }
}

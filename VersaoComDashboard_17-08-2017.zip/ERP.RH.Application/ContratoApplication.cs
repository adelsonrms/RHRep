﻿using RH.Domain.Entities;
using RH.Domain.Repositories;
using RH.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ERP.RH.Application
{
    class ContratoApplication : DataContext
    {
        private IGenericRepository<Contrato> _rep; //Repositório
        private readonly DateService _dtService = new DateService();

        public ContratoApplication()
        {
            _rep = InicializaRepositorio<Contrato>();
        }


        public IEnumerable<Contrato> ObtemRelacaoDeContratos()
        {
            IEnumerable<Contrato> lista;
            try
            {
                lista = _rep.ObterTodos();
            }
            catch (Exception)
            {
                lista = null;
            }

            return lista;
        }


        public Contrato RecuperaContratoPorFuncionario(Funcionario funcionario)
        {
            try
            {
                var repContrato = InicializaRepositorio<Contrato>();
                Contrato contrato = repContrato.ObterTodos().SingleOrDefault(u => u.IdFuncionario == funcionario.Id);

                contrato.Cargo = InicializaRepositorio<Cargo>().ObterPorId(contrato.IdCargo);
                contrato.Modalidade = InicializaRepositorio<Modalidade>().ObterPorId(contrato.IdModalidade);
                contrato.TempoDeCasa = CalculaTempoDeCasa(contrato);
                return contrato;

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                //Caso haja falha, retorna um contrato vazio
                return new Contrato();
                throw;
            }
            

        }

        public string CalculaTempoDeCasa(Contrato contrato)
        {
            try
            {
                DataContrato dt = new DataContrato(contrato);
                return contrato.TempoDeCasa = _dtService.TempoDecorrido(dt.DataInicio, dt.DataFim, "ym");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return "";
                throw;
            }
        }

    }
}

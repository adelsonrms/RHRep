﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RH.Domain.Test
{
    [TestClass]
    public class DbContextTest
    {
        [TestMethod]
        public void ConexaoValida()
        {
        }
    }
}

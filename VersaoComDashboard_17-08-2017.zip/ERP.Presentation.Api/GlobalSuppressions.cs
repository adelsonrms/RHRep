﻿
// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0022:Use expression body for methods", Justification = "<Pending>", Scope = "member", Target = "~M:ERP.Presentation.Api.App_Start.EmailService.SendAsync(Microsoft.AspNet.Identity.IdentityMessage)~System.Threading.Tasks.Task")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0022:Use expression body for methods", Justification = "<Pending>", Scope = "member", Target = "~M:ERP.Presentation.Api.App_Start.SmsService.SendAsync(Microsoft.AspNet.Identity.IdentityMessage)~System.Threading.Tasks.Task")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0022:Use expression body for methods", Justification = "<Pending>", Scope = "member", Target = "~M:ERP.Presentation.Api.App_Start.ApplicationSignInManager.Create(Microsoft.AspNet.Identity.Owin.IdentityFactoryOptions{ERP.Presentation.Api.App_Start.ApplicationSignInManager},Microsoft.Owin.IOwinContext)~ERP.Presentation.Api.App_Start.ApplicationSignInManager")]


﻿using ERP.RH.Application;
using System.Web.Mvc;


namespace RH.UI.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly FuncionarioApplication _app = new FuncionarioApplication();

        public ActionResult Index()
        {
            //Devolve o resultado para View
            return View();
        }


    }
}
﻿namespace RH.Domain.Entities
{
    public class EstadoCivil
    {
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}
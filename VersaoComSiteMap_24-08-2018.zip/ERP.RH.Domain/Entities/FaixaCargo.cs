﻿namespace RH.Domain.Entities
{
    public class FaixaCargo
    {
        public virtual int Id { get; set; }

        public virtual string Faixa { get; set; }
    }
}
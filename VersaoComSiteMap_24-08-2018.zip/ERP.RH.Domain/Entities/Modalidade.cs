﻿namespace RH.Domain.Entities
{
    public class Modalidade
    {
        public virtual int Id { get; set; }
        public virtual string NomeModalidade { get; set; }
    }
}
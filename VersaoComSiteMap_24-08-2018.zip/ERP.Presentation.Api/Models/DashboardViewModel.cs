﻿namespace ERP.Presentation.Api.Models
{
    public class DashboardViewModel
    {
        public int QtdDeFuncionarios { get; set; }
        public int QtdDeClientes { get; set; }
        public int QtdDeFuncionariosAtivos { get; set; }
        public int QtdNovasContratacoesNoAno { get; set; }
    }
}